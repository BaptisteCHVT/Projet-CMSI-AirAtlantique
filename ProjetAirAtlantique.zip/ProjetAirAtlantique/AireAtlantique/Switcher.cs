﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Navigation;





namespace AireAtlantique
{
    public static class Switcher
    {
        public static Page mainPage;
        public static Page Parametre;
        public static Page Formation;
        public static Page ajouterFormation;
        public static Page Session;
        public static Page ajouterSession;
        public static Page ajouterEmployeSession;
        public static Page Employer;
        public static Page ajouterEmployer;
        public static MainWindow mainWin;

    }
}
